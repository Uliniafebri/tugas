/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author Admin
 */
import java.util.*;
public class User {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
	System.out.println("=====================================================");
	System.out.println("======= MARI MENGHITUNG VOLUME BANGUN RUANG =======");
	System.out.println("=====================================================");
        menu1();
	} 
    static void menu1(){
		System.out.println();
		String menu1 = "Pilih Bangun Ruang";
                String menu2 = "Keluar";
		System.out.println("=================================");
		System.out.println("||  BERIKUT PILIHAN MENU UTAMA ||");
		System.out.println("=================================");
		System.out.println("\t1. "+menu1);
		System.out.println("\t2. "+menu2);
		Scanner scan = new Scanner(System.in);
		int input;
		System.out.println();
		System.out.print("Silahkan Pilih Menu : ");
		input = scan.nextInt();
		if( input ==1 ){
			menu();}
		else{
			System.exit(0);
	}
}
    static void menu(){ //funsi untuk menu
	System.out.println();
	System.out.println("===================================");
	System.out.println("|| Berikut Pilihan Bangun Ruang: ||");
	System.out.println("===================================");
	System.out.println("|| 1 . Volume KUBUS              ||");
	System.out.println("|| 2 . Volume BALOK              ||"); 
	System.out.println("|| 3 . Volume PRISMA SEGITIGA    ||");
	System.out.println("|| 4 . Volume LIMAS SEGITIGA     ||");
	System.out.println("|| 5 . Volume LIMAS SEGIEMPAT    ||");
	System.out.println("|| 6 . Volume TABUNG             ||");
	System.out.println("|| 7 . Volume KERUCUT            ||");
	System.out.println("|| 8 . Volume BOLA               ||");
	System.out.println("|| 9. keluar dari program        ||");
	System.out.println("===================================");
	System.out.println();
	Scanner daftar = new Scanner(System.in);
	int bangunruang;
	System.out.print("|| Silahkan pilih menu nomor berapa yang ingin di jalankan : ");
	bangunruang = daftar.nextInt();

	/*
	fungsi if
	*/
	if(bangunruang==1){
	kubus();}
	else if(bangunruang==2){
	balok();}
	else if(bangunruang==3){
	prismasegitiga();}
	else if(bangunruang==4){
	limassegitiga();}
	else if (bangunruang==5){
	limassegiempat();}
	else if (bangunruang==6){
	tabung();}
	else if (bangunruang==7){
	kerucut();}
	else if (bangunruang==8){
	bola();}
	else {
	System.exit(0);}
}

    static void kubus(){
		System.out.println("=========================================");
		System.out.println("||                                     ||");
		System.out.println("||       MENGHITUNG VOLUME KUBUS       ||");
		System.out.println("||                                     ||");
		System.out.println("=========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float s,volumekubus;
		String pilihan;
		System.out.print("\tMasukkan Sisi = ");
		s = angka.nextFloat();
		volumekubus=s*s*s;
		System.out.println("\tVolume Kubus = " + volumekubus);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			kubus();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}
}

    static void balok(){
		System.out.println("=================================================");
		System.out.println("||                                             ||");
		System.out.println("||            MENGHITUNG VOLUME BALOK          ||");
		System.out.println("||                                             ||");
		System.out.println("=================================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float p,l,t,volumebalok;
		String pilihan;
		System.out.print("\tMasukkan Nilai Panjang = ");
		p = angka.nextFloat();
		System.out.print("\tMasukkan nilai lebar = ");
		l = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi = ");
		t = angka.nextFloat();
		volumebalok = p*l*t;
		System.out.println("\tVolume Balok = " + volumebalok);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			balok();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}
}

    static void prismasegitiga(){
		System.out.println("==============================================");
		System.out.println("||                                          ||");
		System.out.println("||    MENGHITUNG VOLUME PRISMA SEGITIGA     ||");
		System.out.println("||                                          ||");
		System.out.println("==============================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
                Scanner plhn = new Scanner(System.in);
		float a,t,Tinggi,volumeprismasegitiga;
		String pilihan;
		System.out.print("\tMasukkan nilai alas segitiga alas = ");
		a = angka.nextFloat();
		System.out.print("\tMasukkan nilai tinggi segitiga alas = ");
		t = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi bangun prisma segitiga = ");
		Tinggi = angka.nextFloat();
		volumeprismasegitiga = a*t*Tinggi/2;
		System.out.println("\tVolume Prisma Segitiga = " + volumeprismasegitiga);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			prismasegitiga();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}

}
    static void limassegitiga(){
		System.out.println("==========================================");
		System.out.println("||                                      ||");
		System.out.println("||   MENGHITUNG VOLUME LIMAS SEGITIGA   ||");
		System.out.println("||                                      ||");
		System.out.println("==========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float a,t,Tinggi,volumelimassegitiga;
		String pilihan;
		System.out.print("\tMasukkan nilai alas segitiga alas = ");
		a = angka.nextFloat();
		System.out.print("\tMasukkan nilai tinggi segitiga alas = ");
		t = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi bangun limas segitiga = ");
		Tinggi = angka.nextFloat();
		volumelimassegitiga = (float) (0.5*a*t*Tinggi/3);
		System.out.println("\tVolume Limas Segitiga = " + volumelimassegitiga);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			limassegitiga();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}

}
    static void limassegiempat(){
		System.out.println("==========================================");
		System.out.println("||                                      ||");
		System.out.println("||   MENGHITUNG VOLUME LIMAS SEGIEMPAT  ||");
		System.out.println("||                                      ||");
		System.out.println("==========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float p,l,Tinggi,volumelimassegiempat;
		String pilihan;
		System.out.print("\tMasukkan nilai panjang alas = ");
		p = angka.nextFloat();
		System.out.print("\tMasukkan nilai lebar alas = ");
		l = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi bangun limas segiempat = ");
		Tinggi = angka.nextFloat();
		volumelimassegiempat = (float) (p*l*Tinggi/3);
		System.out.println("\tVolume Limas Segiempat = " + volumelimassegiempat);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			limassegiempat();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}

}
    static void tabung(){
		System.out.println("==========================================");
		System.out.println("||                                      ||");
		System.out.println("||       MENGHITUNG VOLUME TABUNG      ||");
		System.out.println("||                                      ||");
		System.out.println("==========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float phi,r,Tinggi,volumetabung;
		String pilihan;
		System.out.print("\tMasukkan nilai phi = ");
		phi = angka.nextFloat();
		System.out.print("\tMasukkan nilai jari-jari = ");
		r = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi tabung = ");
		Tinggi = angka.nextFloat();
		volumetabung = (float) (phi*r*r*Tinggi);
		System.out.println("\tVolume Tabung = " + volumetabung);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			tabung();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}

}
    static void kerucut(){
		System.out.println("==========================================");
		System.out.println("||                                      ||");
		System.out.println("||       MENGHITUNG VOLUME KERUCUT      ||");
		System.out.println("||                                      ||");
		System.out.println("==========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float phi,r,Tinggi,volumekerucut;
		String pilihan;
		System.out.print("\tMasukkan nilai phi = ");
		phi = angka.nextFloat();
		System.out.print("\tMasukkan nilai jari-jari = ");
		r = angka.nextFloat();
                System.out.print("\tMasukkan nilai tinggi kerucut = ");
		Tinggi = angka.nextFloat();
		volumekerucut = (float) (phi*r*r*Tinggi/3);
		System.out.println("\tVolume Kerucut = " + volumekerucut);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			kerucut();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("============================================================================");
			System.out.println("||            TERIMAKASIH SUDAH MENGHITUNG VOLUME BANGUN RUANG            ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                        ||");
			System.out.println("============================================================================");
	}

}
    static void bola(){
		System.out.println("==========================================");
		System.out.println("||                                      ||");
		System.out.println("||        MENGHITUNG VOLUME BOLA        ||");
		System.out.println("||                                      ||");
		System.out.println("==========================================");
		System.out.println();
		Scanner angka = new Scanner(System.in);
		Scanner plhn = new Scanner(System.in);
		float phi,r,volumebola;
		String pilihan;
		System.out.print("\tMasukkan nilai phi = ");
		phi = angka.nextFloat();
		System.out.print("\tMasukkan nilai jari-jari = ");
		r = angka.nextFloat();
		volumebola = (float) (4*phi*r*r*r/3);
		System.out.println("\tVolume Bola = " + volumebola);
		System.out.println("Apakah anda ingin mengitung kembali ? (YA/YA BANGUN RUANG LAIN/TIDAK) ");
		pilihan = plhn.nextLine();
			if (pilihan.equals("YA")){
			bola();}
			if(pilihan.equals("YA BANGUN RUANG LAIN")){
			menu();}
			else{
			System.out.println();
			System.out.println();
			System.out.println("========================================================================");
			System.out.println("|| TERIMAKASIH SUDAH MENGGUNAKAN PROGRAM MENGHITUNG LUAS BANGUN DATAR ||");
			System.out.println("||                      SEMOGA HARIMU MENYENANGKAN                    ||");
			System.out.println("========================================================================");
			System.exit(0);
    }
}


}


    

